//
//  ChatMsg.m
//  sockettest
//
//  Created by cyt on 14/11/19.
//  Copyright (c) 2014年 cyt. All rights reserved.
//

#import "ChatMsg.h"

@implementation ChatMsg
@synthesize isMe,content,type,time,date;
@end
