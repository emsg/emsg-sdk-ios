//
//  QNConfig.h
//  QiniuSDK
//
//  Created by bailong on 14-9-29.
//  Copyright (c) 2014年 Qiniu. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const kQNUpHost;

extern NSString *const kQNUpHostBackup;

extern const UInt32 kQNChunkSize;

extern const UInt32 kQNBlockSize;

extern const UInt32 kQNRetryMax;

extern const UInt32 kQNPutThreshold;

extern const float kQNTimeoutInterval;
