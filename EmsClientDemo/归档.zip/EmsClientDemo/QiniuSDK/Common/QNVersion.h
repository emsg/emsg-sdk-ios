//
//  QNVersion.h
//  QiniuSDK
//
//  Created by bailong on 14-9-29.
//  Copyright (c) 2014年 Qiniu. All rights reserved.
//

#import <Foundation/Foundation.h>

static const NSString *kQiniuVersion = @"7.0.6";
